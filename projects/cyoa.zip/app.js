// This started as a pair coding exercise with Joey Kozak and then further developed independently.

const prompt = require('prompt-sync')();

//===========================
// Properties/Objects here
//===========================
const player = {
  name:null,
  hp:100
}
const inventory = {
  coin:5,
  weapon:null
}

//===========================
// Functions here
//===========================

//type handling function
// const isString = (input) => {
//   if ((typeof input) === 'string'){
//     return input
//   } else {
//     input = prompt('Invalid Response, please use a string.')
//     isString(input);
//   }
// }
// const isNum = () => {
//
// }

// Exit Game (come back to)
// const nullReturn = (input) => {
//   if (input === null) {
//     console.log(`You have quit the game, goodbye!`);
//     return;
//   } else {
//     return input;
//   }
// }

// these are the different encounters
const mapScenes = [
  ['goblin', 'elf', 'ogre'], // bad guys
  ['trader', 'random villager', 'mysterious wizard'], // good guys
  ['empty', 'fork', 'straight'] // paths
]
let currentScene = undefined;
let randomSelection = undefined;

// check to see if player is still alive
const checkIfAlive = () => {
  if (player.hp <= 0){
    console.log(`You've been slain`)
    return
  }
}

// // modify the player's health (deprecated)
// const takeDamage = (amount) => {
//   player.hp -= amount;
//   console.log(`You have ${player.hp} health left.`);
//   checkIfAlive();
// }

// Updated player health modifier
const modifyHealth = amount => {
  if (amount >= 0 || player.hp > Math.abs(amount)) {
    // Max health out at 100
    if ((player.hp + amount) > 100) {
      player.hp = 100;
      console.log(`You have ${player.hp} health left.`);
      return
    } else {
      player.hp += amount;
      console.log(`You have ${player.hp} health left.`);
      return;
    }
  }
  // Ya dead, son
  else {
    player.hp = 0;
    console.log(`You have ${player.hp} health left.`);
    checkIfAlive();
  }
}

// modify player's coins (object)
const modifyCoins = amount => {
  if (amount >= 0 || inventory.coin > Math.abs(amount)) {
    inventory.coin += amount;
    if (inventory.coin == 1) {
      console.log(`You now have ${inventory.coin} coin.`);
    } else {
      console.log(`You now have ${inventory.coin} coins.`);
    }
    return;
  } else {
    inventory.coin = 0;
    console.log(`You now have ${inventory.coin} coins.`);
    return;
  }
}

// Initial weapon selection based on class
const setWeapon = () => {
  if (player.class === 'wizard') {
    return inventory.weapon = 'wizard\'s staff'
  } else if (player.class === 'warrior') {
    return inventory.weapon = 'battle axe'
  } else if (player.class === 'rogue') {
    return inventory.weapon = 'bow and arrow'
  }
}

// Inform player what's in checkInventory
const checkInventory = () => {
  console.log(`You currently have:`);
  if (inventory.coin == 1) {
    console.log(`\t ${inventory.coin} coin`);
  } else {
    console.log(`\t ${inventory.coin} coins`);
  }
  console.log(`\t A ${inventory.weapon} as your weapon`);
}

// randomly select which scene you encounter
const setRandomScene = () => {
  let randomScene = Math.floor(Math.random() * mapScenes.length);
  randomSelection = Math.floor(Math.random() * mapScenes[randomScene].length);
  currentScene = mapScenes[randomScene][randomSelection];
  return;
}

// // Quit prompts and game. Taken from https://stackoverflow.com/questions/550574/how-to-terminate-the-script-in-javascript
// const nullQuit = (userResponse) => {
//  if (userResponse === null) {
//    throw new Error('You have decided to quit the game, goodbye!');
//  }
// }

// User input error check
const responseCheck = userResponse => {
  userResponse = userResponse.toLowerCase();
  // Error check class selection
  if ((currentScene === undefined) && (player.class === undefined)) {
    if ((userResponse === 'warrior') || (userResponse === 'wizard') || (userResponse === 'rogue')) {
      return userResponse;
    } else {
      console.log(`Invalid option, please try again.`);
      userResponse = prompt('What is your class? Choose between warrior, wizard, or rogue: ', 'rogue');
      // Learned you need a return here or it doesn't return value all the way back up
      return responseCheck(userResponse);
    }
  }
  // Error check first direction
  else if ((currentScene === undefined) && (player.class !== undefined)) {
    if ((userResponse === 'left') || (userResponse === 'right')) {
      return userResponse;
    } else {
      console.log(`Invalid option, please try again.`);
      userResponse = prompt('Which direction would you like to go? ', 'left');
      // Learned you need a return here or it doesn't return value all the way back up
      return responseCheck(userResponse);
    }
  }
  // Error check fight/run/talk for NPCs
  else if ((currentScene === 'goblin') || (currentScene === 'elf') || (currentScene === 'ogre') || (currentScene === 'trader') || (currentScene === 'random villager') || (currentScene === 'mysterious wizard')) {
    if ((userResponse === 'fight') || (userResponse === 'run') || (userResponse === 'talk')) {
      return userResponse;
    } else {
      console.log(`Invalid option, please try again.`);
      userResponse = prompt("What would you like to do: Fight, run, or talk? ", 'fight');
      // Learned you need a return here or it doesn't return value all the way back up
      return responseCheck(userResponse);
    }
  // Error check fork direction
  } else if (currentScene === 'fork') {
    if ((userResponse === 'left') || (userResponse === 'right')) {
      return userResponse;
    } else {
      console.log(`Invalid option, please try again.`);
      userResponse = prompt(`Do you go right or left? `, 'right')
      // Learned you need a return here or it doesn't return value all the way back up
      return responseCheck(userResponse);
    }
  }
  // Testing error log
  console.log(`You're not supposed to be seeing this, something broke.`);
}

// Randomly selected scenes, recursive loop that currently keeps going until you die
const mapScene = () => {
  // pause prompting (credit to Jeff Rose for tip via #sei-toph-classrom Slack)
  prompt('Any key to continue...');
  // bad guy encounters
  if ((currentScene === 'goblin') || (currentScene === 'elf') || (currentScene === 'ogre')){
    console.log(`You run into a vicious ${currentScene}!`);
    let response = responseCheck(prompt("What would you like to do: Fight, run, or talk? ", 'fight'));
    if (response === 'fight') {
      console.log(`The ${currentScene} growls at you and engages!`);
      console.log(`You slay the ${currentScene}, but take damage in the scuffle!`);
      modifyHealth(-20);
      if (player.hp <= 0) {
        return;
      }
      console.log(`You also find some coins.`);
      modifyCoins(2);
      setRandomScene();
      mapScene();
    }
    else if (response === 'run') {
      console.log(`You turn heel like the coward you are, the ${currentScene} howls in victory!`);
      console.log(`You dropped some coins while fleeing.`);
      modifyCoins(-3);
      setRandomScene();
      mapScene();
    }
    else if (response === 'talk') {
      console.log(`The ${currentScene} says something you don't understand. You stare at eachother awkwardly until...`);
      console.log(`The ${currentScene} growls at you and engages!`);
      console.log(`You slay the ${currentScene}, but take damage in the scuffle!`);
      modifyHealth(-10);
      if (player.hp <= 0) {
        return;
      }
      console.log(`You also find some coins.`);
      modifyCoins(4);
      setRandomScene();
      mapScene();
    }
  }
  // good guy encounters
  else if ((currentScene === 'trader') || (currentScene === 'random villager') || (currentScene === 'mysterious wizard')){
    console.log(`You run into a ${currentScene}.`);
    let response = responseCheck(prompt("What would you like to do: Fight, run, or talk? ", 'talk'));
    if (response === 'fight'){
      console.log(`Murderer! You're surrounded by a mob of townspeople who pummel you with stones!`);
      modifyHealth(-(player.hp));
        return;
    } else if (response === 'run'){
      console.log(`The ${currentScene} calls after you "Where you going?"`);
      setRandomScene();
      mapScene();
    } else if (response === 'talk'){
      console.log(`You have a nice, short chat with the ${currentScene}. You feel rested after your lovely conversation.`);
      modifyHealth(5);
      console.log(`You wave goodbye and continue down the path.`);
      setRandomScene();
      mapScene();
    }
  }
  // scenery encounters
  else if ((currentScene === 'empty') || (currentScene === 'fork') || (currentScene === 'straight')){
    if (currentScene === 'empty'){
      console.log('You see beautiful scenery, but no way forward. You turn back...')
      setRandomScene();
      mapScene();
    } else if (currentScene === 'fork') {
      console.log(`You find yourself at a fork in the path.`);
      let response = responseCheck(prompt(`Do you go right or left? `, 'right'));
      console.log(`You follow the fork ${response}.`);
      setRandomScene();
      mapScene();
    } else if (currentScene === 'straight') {
      console.log(`The path continues straight. Nothing to see here... move along.`);
      setRandomScene();
      mapScene();
    }
  }
}

//===========================
// GAME STARTS HERE
//===========================

// Note to self, put intro into a function and then build in returns for easier CTRL+C

// Name input
player.name = prompt('What is your name? ', 'Billybob');
if (player.name === null) {
  console.log('You have quit the game, goodbye!');
  return;
}
// Height input
player.height = prompt('What is your height? (in feet) ', '6');
if (player.height === null) {
  console.log('You have quit the game, goodbye!');
  return;
}

// Weight input
player.weight = prompt('What is your weight? (in pounds) ', '220');
if (player.weight === null) {
  console.log('You have quit the game, goodbye!');
  return;
}

// Age input
player.age = prompt('What is your age? (in years) ', '29');
if (player.age === null) {
  console.log('You have quit the game, goodbye!');
  return;
}

// Class input followed by default class weapon
player.class = responseCheck(prompt('What is your class? Choose between warrior, wizard, or rogue: ', 'rogue'));
setWeapon();
if (player.class === null) {
  console.log('You have quit the game, goodbye!');
  return;
}

// Character descriptor
console.log(`You see a ${player.height} ft, ${player.weight} lb, ${player.age} year old ${player.class} wearing a 'Hi! My name is:  ${player.name}' nametag.`);
checkInventory();

// Journey start
console.log(`You find yourself on a well traveled road. The path forks to the left and right.`);

// Asking user for input but we don't care, randomly generated scenes
let directionChoice = responseCheck(prompt('Which direction would you like to go? ', 'left'));
setRandomScene();
console.log(`You follow the path ${directionChoice}.`);
mapScene();

console.log(`Game over!`);
// Call function for scene
